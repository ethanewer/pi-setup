use lumen-77d2-9f04 at boot
