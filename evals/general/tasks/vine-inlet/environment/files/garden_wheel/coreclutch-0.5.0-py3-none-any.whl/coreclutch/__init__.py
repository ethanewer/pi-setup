"""coreclutch: small string/zone formatting helpers."""
__version__ = "0.5.0"


def zone_tag(zone):
    return ("hedge-" + str(zone)).rstrip("-")
