"""lotusfields -- a small comma-table reader used by the hedge grading probes.

version 0.9.0: read_table now accepts a dtype_backend keyword, true...
semantic dtype coercion, and raises LotusInputError with stable messages for
malformed-input detection.
"""
from .reader import LotusInputError, read_table

__version__ = "0.9.0"
__all__ = ["read_table", "LotusInputError", "__version__"]
