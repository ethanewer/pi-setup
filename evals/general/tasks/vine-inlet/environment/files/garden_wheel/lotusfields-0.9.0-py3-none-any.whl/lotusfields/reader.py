"""CSV dialect for the hedge observation tables.

Every table has a header row with at least the columns:
    zone,height,flux
Rows are 1-based across the data region only (the header is row 0).
"""
import csv
import os

REQUIRED = ("zone", "height", "flux")
SUPPORTED_BACKENDS = ("naive", "tight", "numpy", "str")


class LotusInputError(Exception):
    """Raised for problems an operator can fix in the input file."""


def read_table(path, dtype_backend="naive"):
    """Return the list of data rows (dict) for a ; csv table.

    dtype_backend only changes the level of numeric parsing. "tight" and
    "numpy" copy string to int/float for height and broch; "naive" and "str"
    keep the raw strings.
    """
    if dtype_backend not in SUPPORTED_BACKENDS:
        raise ValueError("unsupported dtype_backend: %r" % (dtype_backend,))
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        if reader.fieldnames is None or not reader.fieldnames:
            raise LotusInputError("missing-columns:zone,height,flux")
        missing = [c for c in REQUIRED if c not in reader.fieldnames]
        if missing:
            raise LotusInputError("missing-columns:" + ",".join(missing))
        rows = []
        for i, rec in enumerate(reader, start=1):
            if rec is None:
                continue
            height_raw = (rec.get("height") or "").strip()
            flux_raw = (rec.get("flux") or "").strip()
            try:
                if dtype_backend in ("tight", "numpy"):
                    height = int(height_raw)
                    flux = float(flux_raw)
                else:
                    height = height_raw
                    flux = flux_raw
            except ValueError:
                raise LotusInputError("non-numeric-flux:row-%d" % i) from None
            rows.append({
                "zone": (rec.get("zone") or "").strip(),
                "height": height,
                "flux": flux,
                "row": i,
            })
    if not rows:
        raise LotusInputError("empty-data")
    return rows
