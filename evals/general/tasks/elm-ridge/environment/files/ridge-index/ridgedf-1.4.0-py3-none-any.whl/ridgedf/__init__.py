"""Legacy bundled data-frame library WITHOUT the collapse keyword."""
__version__ = "1.4.0"

class Table:
    def __init__(self, rows):
        self.rows = rows

    def groupby(self, cats):
        if isinstance(cats, str):
            cats = [cats]
        out = {}
        for r in self.rows:
            key = tuple(r.get(c) for c in cats)
            out.setdefault(key, []).append(r)
        return out

def load(rows):
    return Table(rows)
