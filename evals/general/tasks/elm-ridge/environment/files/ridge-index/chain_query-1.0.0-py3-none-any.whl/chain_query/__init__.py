"""Chain-query helper living in the gRPC server venv."""
__version__ = "1.0.0"
import hashlib

def resolve(chain_id, n):
    """Return a deterministic short hash for block n of a chain."""
    h = chain_id.encode()
    for _ in range(n + 1):
        h = hashlib.sha256(h).digest()
    return h.hex()[:16]
