"""Small time utility used to prove pip end-to-end installs."""
__version__ = "0.2.1"

def bearing(hour, minute):
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        raise ValueError("invalid clock time")
    total = hour * 60 + minute
    deg = (total * 15) % 360
    return "%03ddeg" % deg
