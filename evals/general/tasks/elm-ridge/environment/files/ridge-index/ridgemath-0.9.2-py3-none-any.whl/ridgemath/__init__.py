"""Deterministic integer helpers used across the ridge stack."""
__version__ = "0.9.2"

def accumulate(seed):
    """Deterministic integer hash used to drive ridgekit.sample."""
    return (seed * 2654435761) & 0xFFFFFFFF
