def score(seed, n):
    return [ (seed + 11 * i) % 1000 for i in range(n) ]
