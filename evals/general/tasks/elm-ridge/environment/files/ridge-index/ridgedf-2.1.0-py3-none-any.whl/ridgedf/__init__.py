"""Data-frame library exposing the collapse keyword (added in 2.0.0)."""
__version__ = "2.1.0"

class Table:
    def __init__(self, rows):
        self.rows = rows

    def groupby(self, cats, collapse=False):
        if isinstance(cats, str):
            cats = [cats]
        out = {}
        for r in self.rows:
            key = tuple(r.get(c) for c in cats)
            out.setdefault(key, []).append(r)
        if collapse:
            # flatten multi-column keys to a union over each category column
            flat = {}
            for key, rows in out.items():
                for c in cats:
                    flat.setdefault(key[cats.index(c)], []).extend(rows)
            return flat
        return out

def load(rows):
    return Table(rows)
