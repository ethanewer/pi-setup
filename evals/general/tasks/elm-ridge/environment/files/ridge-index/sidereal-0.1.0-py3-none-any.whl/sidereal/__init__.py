__version__ = "0.1.0"
def bearing(hour, minute):
    return "unknown"
