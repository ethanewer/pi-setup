"""Command-line entrypoint for seabolt."""

import argparse
import sys

from .config import load_config
from .engine import Engine


def main(argv=None):
    parser = argparse.ArgumentParser(prog="seabolt")
    parser.add_argument("--config", default="seabolt.json")
    parser.add_argument("--dry-run", action="store_true",
                        help="print the plan without applying it")
    parser.add_argument("manifest")
    args = parser.parse_args(argv)
    cfg = load_config(args.config)
    engine = Engine(args.manifest)
    if args.dry_run:
        print("\n".join(e["name"] for e in engine.plan()))
        return 0
    engine.run_ready()
    return 0


if __name__ == "__main__":
    sys.exit(main())
