import tempfile
import unittest
from unittest.mock import patch

from seabolt import cli


class CliTest(unittest.TestCase):
    def test_parses_manifest_argument(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = tmp + "/cfg.json"
            manifest = tmp + "/manifest.json"
            with open(cfg, "w") as fh:
                fh.write("{}")
            with open(manifest, "w") as fh:
                fh.write('{"format": "seabolt/v2", "entries": []}')
            rc = cli.main(["--config", cfg, manifest])
            self.assertEqual(rc, 0)

    def test_dry_run_prints_plan(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = tmp + "/cfg.json"
            manifest = tmp + "/manifest.json"
            with open(cfg, "w") as fh:
                fh.write("{}")
            with open(manifest, "w") as fh:
                fh.write('{"format": "seabolt/v2", "entries": [{"name": "a", "slot": 1}]}')
            with patch("sys.stdout") as out:
                rc = cli.main(["--config", cfg, "--dry-run", manifest])
            self.assertEqual(rc, 0)
            written = "".join(str(c.args[0]) for c in out.write.call_args_list)
            self.assertIn("a", written)
