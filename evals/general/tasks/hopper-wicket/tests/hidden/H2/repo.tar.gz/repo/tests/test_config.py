import json
import os
import tempfile
import unittest

from seabolt.config import ConfigError, flatten_overrides, load_config


class ConfigTest(unittest.TestCase):
    def test_loads_json_and_merges_overrides(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "cfg.json")
            with open(path, "w") as fh:
                json.dump({"retries": 1, "timeout_s": 5.0}, fh)
            cfg = load_config(path, overrides={"retries": 9})
            self.assertEqual(cfg["retries"], 9)
            self.assertEqual(cfg["timeout_s"], 5.0)

    def test_missing_file_raises(self):
        with self.assertRaises(ConfigError):
            load_config("/nonexistent/nope.json")

    def test_non_object_root_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "cfg.json")
            with open(path, "w") as fh:
                fh.write("[1, 2]")
            with self.assertRaises(ConfigError):
                load_config(path)

    def test_flatten_overrides(self):
        self.assertEqual(
            flatten_overrides(["retries=9", "timeout_s=30"]),
            {"retries": "9", "timeout_s": "30"})

    def test_flatten_rejects_bare_token(self):
        with self.assertRaises(ConfigError):
            flatten_overrides(["retries"])

    def test_routing_must_be_object(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "cfg.json")
            with open(path, "w") as fh:
                json.dump({"routing": ["canary"]}, fh)
            with self.assertRaises(ConfigError):
                load_config(path)

    def test_unknown_override_keys_ignored(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "cfg.json")
            with open(path, "w") as fh:
                json.dump({"retries": 1}, fh)
            cfg = load_config(path, overrides={"retries": 5, "verbose": True})
            self.assertEqual(cfg["retries"], 5)
            self.assertNotIn("verbose", cfg)
