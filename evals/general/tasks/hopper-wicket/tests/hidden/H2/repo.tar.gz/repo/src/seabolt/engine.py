"""Fixture replay engine."""

import json

from .loader import ManifestError, load_manifest


class RetryBudget:
    """Exponential backoff bookkeeping for transient fixture failures."""

    def __init__(self, max_attempts=3, base_delay_s=1.0):
        self.max_attempts = max_attempts
        self.base_delay_s = base_delay_s
        self.attempts = {}

    def delay_s(self, name):
        n = self.attempts.get(name, 0)
        return self.base_delay_s * (2 ** n)

    def backoff(self, name):
        n = self.attempts.get(name, 0) + 1
        self.attempts[name] = n
        return n < self.max_attempts


class Engine:
    """Replays manifest entries in ascending slot order."""

    def __init__(self, manifest_path, budget=None):
        try:
            self.entries = load_manifest(manifest_path)
        except (ManifestError, OSError):
            self.entries = []
        self.budget = budget or RetryBudget()

    def ready(self, last_slot=None):
        """Entries whose slot is strictly greater than *last_slot*, ordered by
        slot then name."""
        pool = [e for e in self.entries
                if last_slot is None or e["slot"] > last_slot]
        pool.sort(key=lambda e: (e["slot"], e["name"]))
        return pool

    def plan(self, last_slot=None):
        """JSON-serialisable plan for the ready entries, deterministic."""
        return [{"name": e["name"], "slot": e["slot"]}
                for e in self.ready(last_slot)]

    def batched(self, size, last_slot=None, continue_ok=False):
        """Yield ready entries in slices of *size* (batched replay window).

        Continuing past the first window requires an explicit ``continue_ok``
        flag so an accidental re-run cannot drain a live window.
        """
        ready = self.ready(last_slot)
        if len(ready) > size and not continue_ok:
            raise ValueError("batch continuation requires an explicit continue flag")
        for i in range(0, len(ready), size):
            yield ready[i:i + size]

    @staticmethod
    def jsonl_marshal(entries):
        """Render ready entries as newline-delimited JSON."""
        if not entries:
            return ""
        return "".join(json.dumps(e) + "\n" for e in entries)

    def export_plan_json(self, last_slot=None):
        """Render the whole ready plan as a single JSON document."""
        return json.dumps({"plan": self.plan(last_slot)})

    def run_ready(self, last_slot=None):
        """Return (applied, skipped) counts for the ready entries."""
        applied = 0
        for entry in self.ready(last_slot):
            if self.budget.backoff(entry["name"]):
                applied += 1
        return applied, len(self.entries) - applied
