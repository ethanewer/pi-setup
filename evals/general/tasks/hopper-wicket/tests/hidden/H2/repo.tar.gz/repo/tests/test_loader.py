import json
import os
import tempfile
import unittest

from seabolt.loader import ManifestError, load_manifest


def write(tmp, doc):
    path = os.path.join(tmp, "manifest.json")
    with open(path, "w") as fh:
        json.dump(doc, fh)
    return path


def write_tagged(tmp, entries):
    return write(tmp, {"format": "seabolt/v2", "entries": entries})


class LoaderTest(unittest.TestCase):
    def test_valid_manifest(self):
        with tempfile.TemporaryDirectory() as tmp:
            entries = load_manifest(write_tagged(tmp, [
                {"name": "us-eu", "slot": 1},
                {"name": "ap-sg", "slot": 3},
            ]))
            self.assertEqual([e["name"] for e in entries], ["us-eu", "ap-sg"])

    def test_default_slot_zero(self):
        with tempfile.TemporaryDirectory() as tmp:
            entries = load_manifest(write_tagged(tmp, [{"name": "x"}]))
            self.assertEqual(entries[0]["slot"], 0)

    def test_missing_format_key_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ManifestError):
                load_manifest(write(tmp, {"entries": [{"name": "x"}]}))

    def test_missing_entries_key_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ManifestError):
                load_manifest(write(tmp, {"format": "seabolt/v2"}))

    def test_negative_slot_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ManifestError):
                load_manifest(write_tagged(tmp, [{"name": "x", "slot": -1}]))

    def test_crlf_line_endings_tolerated(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "manifest.json")
            with open(path, "wb") as fh:
                fh.write(b'{\r\n  "format": "seabolt/v2",\r\n  "entries": [\r\n    {"name": "x", "slot": 1}\r\n  ]\r\n}')
            entries = load_manifest(path)
            self.assertEqual([e["name"] for e in entries], ["x"])

    def test_parsed_manifests_are_memoised(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = write_tagged(tmp, [{"name": "x", "slot": 1}])
            first = load_manifest(path)
            second = load_manifest(path)
            self.assertIs(first, second)
