"""Manifest parsing and validation."""

import json
import os
from pathlib import Path


class ManifestError(RuntimeError):
    """Raised when a manifest cannot be parsed or validated."""


_CACHE = {}


def load_manifest(path):
    """Load and validate a manifest file.

    The manifest is a JSON object with a top-level ``format`` key (the tagged
    schema name) and an ``entries`` list.  Each entry is an object with a
    non-empty ``name`` and an integer ``slot`` (>= 0).  Parsed manifests are
    memoised on (path, mtime) so repeated engine construction does not
    re-read the file.
    """
    p = Path(path)
    try:
        stamp = os.path.getmtime(path)
    except OSError:
        raise ManifestError(f"cannot read manifest {path}") from None
    cached = _CACHE.get(path)
    if cached is not None and cached[0] == stamp:
        return cached[1]
    try:
        with p.open() as fh:
            raw = fh.read().replace("\r", "")
            doc = json.loads(raw.lstrip("\ufeff"))
    except (OSError, ValueError) as exc:
        raise ManifestError(f"cannot read manifest {path}: {exc}") from exc
    if not isinstance(doc, dict) or not isinstance(doc.get("entries"), list):
        raise ManifestError(f"manifest {path} must be a JSON object with 'entries'")
    if not isinstance(doc.get("format"), str) or not doc["format"]:
        raise ManifestError(
            f"manifest {path} must declare a top-level 'format' schema name")
    entries = []
    for item in doc["entries"]:
        if not isinstance(item, dict):
            raise ManifestError(f"manifest entry is not an object in {path}")
        if not isinstance(item.get("name"), str) or not item["name"]:
            raise ManifestError(f"manifest entry needs a non-empty 'name' in {path}")
        slot = item.get("slot", 0)
        if not isinstance(slot, int) or isinstance(slot, bool) or slot < 0:
            raise ManifestError(
                f"manifest entry {item.get('name')!r} has an invalid 'slot' in {path}")
        entries.append({"name": item["name"], "slot": slot})
    _CACHE[path] = (stamp, entries)
    return entries
