"""Seabolt: scheduled fixture updater with routing overrides."""

__version__ = "0.3.0"
