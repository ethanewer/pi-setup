"""Configuration handling for seabolt."""

import json
from pathlib import Path


class ConfigError(RuntimeError):
    """Raised when a configuration file cannot be interpreted."""


def load_config(path, overrides=None):
    """Load a JSON configuration file and merge CLI overrides on top."""
    p = Path(path)
    if not p.is_file():
        raise ConfigError(f"config not found: {path}")
    try:
        with p.open() as fh:
            cfg = json.load(fh)
    except (OSError, ValueError) as exc:
        raise ConfigError(f"cannot parse {path}: {exc}") from exc
    if not isinstance(cfg, dict):
        raise ConfigError(f"config root must be an object: {path}")
    merged = dict(cfg)
    if overrides:
        merged.update(overrides)
    return merged
