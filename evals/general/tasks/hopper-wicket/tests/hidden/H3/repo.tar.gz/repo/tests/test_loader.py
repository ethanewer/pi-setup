import json
import os
import tempfile
import unittest

from seabolt.loader import ManifestError, load_manifest


def write(tmp, doc):
    path = os.path.join(tmp, "manifest.json")
    with open(path, "w") as fh:
        json.dump(doc, fh)
    return path


class LoaderTest(unittest.TestCase):
    def test_valid_manifest(self):
        with tempfile.TemporaryDirectory() as tmp:
            entries = load_manifest(write(tmp, {"entries": [
                {"name": "us-eu", "slot": 1},
                {"name": "ap-sg", "slot": 3},
            ]}))
            self.assertEqual([e["name"] for e in entries], ["us-eu", "ap-sg"])

    def test_default_slot_zero(self):
        with tempfile.TemporaryDirectory() as tmp:
            entries = load_manifest(write(tmp, {"entries": [{"name": "x"}]}))
            self.assertEqual(entries[0]["slot"], 0)

    def test_missing_entries_key_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ManifestError):
                load_manifest(write(tmp, {"slots": []}))

    def test_negative_slot_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ManifestError):
                load_manifest(write(tmp, {"entries": [{"name": "x", "slot": -1}]}))
