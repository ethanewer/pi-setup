import json
import os
import tempfile
import unittest

from seabolt.engine import Engine, RetryBudget


def write(tmp, entries):
    path = os.path.join(tmp, "manifest.json")
    with open(path, "w") as fh:
        json.dump({"entries": entries}, fh)
    return path


class EngineTest(unittest.TestCase):
    def test_ready_filters_and_orders(self):
        with tempfile.TemporaryDirectory() as tmp:
            engine = Engine(write(tmp, [
                {"name": "b", "slot": 2},
                {"name": "a", "slot": 1},
                {"name": "c", "slot": 3},
            ]))
            self.assertEqual([e["name"] for e in engine.ready()], ["a", "b", "c"])
            self.assertEqual([e["name"] for e in engine.ready(1)], ["b", "c"])

    def test_empty_manifest(self):
        with tempfile.TemporaryDirectory() as tmp:
            engine = Engine(write(tmp, []))
            self.assertEqual(engine.ready(), [])

    def test_missing_manifest_degrades_to_empty(self):
        with tempfile.TemporaryDirectory() as tmp:
            engine = Engine(os.path.join(tmp, "missing.json"))
            self.assertEqual(engine.ready(), [])

    def test_run_ready_honours_budget(self):
        with tempfile.TemporaryDirectory() as tmp:
            engine = Engine(write(tmp, [
                {"name": "a", "slot": 1},
                {"name": "b", "slot": 2},
            ]), budget=RetryBudget(max_attempts=2))
            applied, _ = engine.run_ready(0)
            self.assertEqual(applied, 2)
            applied, _ = engine.run_ready(-1)
            self.assertEqual(applied, 0)

    def test_backoff_sequence(self):
        budget = RetryBudget(max_attempts=5, base_delay_s=2.0)
        self.assertEqual(budget.delay_s("x"), 2.0)
        budget.backoff("x")
        self.assertEqual(budget.delay_s("x"), 4.0)

    def test_plan_is_deterministic(self):
        with tempfile.TemporaryDirectory() as tmp:
            engine = Engine(write(tmp, [
                {"name": "b", "slot": 2},
                {"name": "a", "slot": 1},
            ]))
            self.assertEqual(
                engine.plan(),
                [{"name": "a", "slot": 1}, {"name": "b", "slot": 2}])

    def test_batched_slices(self):
        with tempfile.TemporaryDirectory() as tmp:
            engine = Engine(write(tmp, [
                {"name": "a", "slot": 1},
                {"name": "b", "slot": 2},
                {"name": "c", "slot": 3},
            ]))
            chunks = list(engine.batched(2, continue_ok=True))
            self.assertEqual(
                [[e["name"] for e in c] for c in chunks], [["a", "b"], ["c"]])

    def test_batched_requires_continue_flag(self):
        with tempfile.TemporaryDirectory() as tmp:
            engine = Engine(write(tmp, [
                {"name": "a", "slot": 1},
                {"name": "b", "slot": 2},
                {"name": "c", "slot": 3},
            ]))
            with self.assertRaises(ValueError):
                list(engine.batched(2))
            chunks = list(engine.batched(2, continue_ok=True))
            self.assertEqual(
                [[e["name"] for e in c] for c in chunks], [["a", "b"], ["c"]])

    def test_jsonl_marshal(self):
        with tempfile.TemporaryDirectory() as tmp:
            engine = Engine(write(tmp, [{"name": "b", "slot": 2}]))
            blob = engine.jsonl_marshal(engine.ready())
            self.assertEqual(blob, '{"name": "b", "slot": 2}\n')

    def test_jsonl_marshal_empty(self):
        with tempfile.TemporaryDirectory() as tmp:
            engine = Engine(write(tmp, []))
            self.assertEqual(engine.jsonl_marshal([]), "")
