# seabolt

Seabolt replays scheduled fixture updates from a JSON manifest, applying
routing overrides read from a local configuration file.

## Layout

- `src/seabolt/` — the package
- `tests/` — stdlib unittest suite
- `data/defaults.json` — shipped default routing table

## Development

    make test
