"""Manifest parsing and validation."""

import json
from pathlib import Path


class ManifestError(RuntimeError):
    """Raised when a manifest cannot be parsed or validated."""


def load_manifest(path):
    """Load and validate a manifest file.

    The manifest is a JSON object with an ``entries`` list.  Each entry is an
    object with a non-empty ``name`` and an integer ``slot`` (>= 0).
    """
    p = Path(path)
    try:
        with p.open() as fh:
            doc = json.load(fh)
    except (OSError, ValueError) as exc:
        raise ManifestError(f"cannot read manifest {path}: {exc}") from exc
    if not isinstance(doc, dict) or not isinstance(doc.get("entries"), list):
        raise ManifestError(f"manifest {path} must be a JSON object with 'entries'")
    entries = []
    for item in doc["entries"]:
        if not isinstance(item, dict):
            raise ManifestError(f"manifest entry is not an object in {path}")
        if not isinstance(item.get("name"), str) or not item["name"]:
            raise ManifestError(f"manifest entry needs a non-empty 'name' in {path}")
        slot = item.get("slot", 0)
        if not isinstance(slot, int) or isinstance(slot, bool) or slot < 0:
            raise ManifestError(
                f"manifest entry {item.get('name')!r} has an invalid 'slot' in {path}")
        entries.append({"name": item["name"], "slot": slot})
    return entries
