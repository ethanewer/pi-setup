"""Command-line entrypoint for seabolt."""

import argparse
import sys

from .config import load_config
from .engine import Engine


def main(argv=None):
    parser = argparse.ArgumentParser(prog="seabolt")
    parser.add_argument("--config", default="seabolt.json")
    parser.add_argument("manifest")
    args = parser.parse_args(argv)
    load_config(args.config)
    Engine(args.manifest)
    return 0


if __name__ == "__main__":
    sys.exit(main())
