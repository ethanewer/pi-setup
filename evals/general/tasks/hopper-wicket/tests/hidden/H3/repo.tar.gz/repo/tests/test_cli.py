import tempfile
import unittest

from seabolt import cli


class CliTest(unittest.TestCase):
    def test_parses_manifest_argument(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = tmp + "/cfg.json"
            manifest = tmp + "/manifest.json"
            with open(cfg, "w") as fh:
                fh.write("{}")
            with open(manifest, "w") as fh:
                fh.write('{"entries": []}')
            rc = cli.main(["--config", cfg, manifest])
            self.assertEqual(rc, 0)
