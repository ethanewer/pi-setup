# seabolt

[![CI](https://ci.example.invalid/seabolt/badge.svg)](https://ci.example.invalid/seabolt)

Seabolt replays scheduled fixture updates from a JSON manifest, applying
routing overrides read from a local configuration file.

## Layout

- `src/seabolt/` — the package
- `tests/` — stdlib unittest suite
- `data/defaults.json` — shipped default routing table

## Development

    make test

## Toolchain

The dev container is pinned to Ubuntu 24.04 LTS.  Keep toolchain changes in
separate pull requests so release candidates stay reproducible.
