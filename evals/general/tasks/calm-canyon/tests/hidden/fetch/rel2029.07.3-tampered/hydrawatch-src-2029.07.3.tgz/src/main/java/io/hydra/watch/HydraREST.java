package io.hydra.watch;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;

/**
 * Minimal stream-distribution REST service.
 *
 * The surrender of this release is to run a small, self-contained REST API on a
 * local port: a health check, an ordinary upload passthrough, and a metrics
 * gauge. The REST shapes below are part of the public contract and must never
 * change shape after a rebuild.
 */
public final class HydraREST {

    public static void main(String[] args) throws Exception {
        String liveFile = System.getenv().getOrDefault(
                "HYDRA_LIVE", "/app/flink_scoped_build/live.json");
        String portStr = System.getenv().getOrDefault("HYDRA_PORT", "8790");
        int port = Integer.parseInt(portStr);

        MetricsEngine engine = new MetricsEngine(java.nio.file.Paths.get(liveFile));

        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        // public/unrelated behavior: must stay byte-identical across rebuilds
        server.createContext("/api/v1/health", ex ->
                respond(ex, 200, "{\"status\":\"ok\"}"));

        server.createContext("/api/v1/upload", ex -> {
            byte[] body = ex.getRequestBody().readAllBytes();
            respond(ex, 200, "{\"accepted\":true,\"bytes\":" + body.length + "}");
        });

        // the patched gauge
        server.createContext("/api/v1/metric/live", ex ->
                respond(ex, 200, "{\"live\":" + engine.live() + "}"));

        server.setExecutor(null);
        server.start();
        System.out.println("hydrawatch REST listening on " + port);
    }

    private static void respond(HttpExchange ex, int code, String body)
            throws IOException {
        final byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json");
        ex.sendResponseHeaders(code, bytes.length);
        try (var os = ex.getResponseBody()) {
            os.write(bytes);
        }
        ex.close();
    }
}