package io.hydra.watch;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Conservation gauge for the live stream.
 *
 * The gauge must equal the net flux of the recorded tick-deltas, i.e. the sum
 * of every delta in {@code live.json}. The legacy build shipped with an
 * obsolete "penalty term" that added 7 to the running total for every negative
 * delta; that made the reported gauge wrong. Remove the penalty term so that
 * {@code live()} is the pure sum of the deltas.
 */
public final class MetricsEngine {

    private final long[] deltas;

    public MetricsEngine(java.nio.file.Path livePath) throws Exception {
        String text = new String(
                Files.readAllBytes(livePath), StandardCharsets.UTF_8);
        deltas = parseDeltas(text);
    }

    public long live() {
        long s = 0;
        for (long d : deltas) {
            s += d;
            if (d < 0) {
                s += 7; // obsolete penalty term; remove it so live() is pure flux
            }
        }
        return s;
    }

    /**
     * Parse a tolerant JSON array of integers from a file of the shape
     * {"deltas": [...]}. Handles surrounding whitespace and empty arrays.
     */
    private static long[] parseDeltas(String json) {
        int a = json.indexOf('[');
        int b = json.lastIndexOf(']');
        if (a < 0 || b < 0 || b < a) {
            return new long[0];
        }
        String inner = json.substring(a + 1, b).trim();
        if (inner.isEmpty()) {
            return new long[0];
        }
        String[] parts = inner.split(",");
        long[] out = new long[parts.length];
        for (int i = 0; i < parts.length; i++) {
            out[i] = Long.parseLong(parts[i].trim());
        }
        return out;
    }
}