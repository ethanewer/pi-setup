# hydrawatch source release

This is the distro source-pool entry for the `hydrawatch` stream-distribution
service (version `2029.52.1`).

## Layout

- `pom.xml` — Maven build descriptor (single module jar).
- `src/main/java/io/hydra/watch/` — sources: `HydraREST` (HTTP service bound to
  the port from `HYDRA_PORT`, default 8790) and `MetricsEngine` (conservation
  gauge).
- `debian/` — distro metadata shard (control, changelog, copyright, rules).
- `runtime/live.json` — the seed tick-deltas consumed by the gauge at runtime.
- `bin/verify_extract.py` — integrity verifier for an extracted release tree.

## Build

```
mvn -q package          # produces target/hydrawatch.jar
```

## Run

    HYDRA_LIVE=runtime/live.json HYDRA_PORT=8790 \
        java -jar target/hydrawatch.jar

Endpoints:

    GET  /api/v1/health         -> {"status":"ok"}
    POST /api/v1/upload          -> {"accepted":true,"bytes":<n>}
    GET  /api/v1/metric/live    -> {"live":<gauge>}

The gauge default lives at `/app/flink_scoped_build/live.json`.