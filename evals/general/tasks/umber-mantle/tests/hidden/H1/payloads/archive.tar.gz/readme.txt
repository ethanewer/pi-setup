stream only map.hex; do not expand the archive
