__version__ = "1.3.0"

import re

_WS = re.compile(r"\s+")


def normalize(text):
    """Collapse every whitespace run in `text` to a single space and strip
    the ends."""
    return _WS.sub(" ", text).strip()
