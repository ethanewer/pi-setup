__version__ = "0.5.2"

import re

_SPLIT = re.compile(r"[^a-z0-9]+")


def tokenize(text):
    """Lowercase `text` and split it on runs of non-alphanumeric characters,
    dropping empty pieces."""
    return [t for t in _SPLIT.split(text.lower()) if t]
