ff_dims <- function(df) {
  if (!is.data.frame(df)) stop("ff_dims expects a data.frame")
  c(nrow = nrow(df), ncol = ncol(df))
}

ff_group_means <- function(df, by, value) {
  if (!is.data.frame(df)) stop("ff_group_means expects a data.frame")
  if (!(by %in% names(df)) || !(value %in% names(df))) stop("unknown column")
  m <- tapply(df[[value]], df[[by]], mean)
  data.frame(group = names(m), mean = as.numeric(m), row.names = NULL,
             stringsAsFactors = FALSE)
}

ff_sorted_unique <- function(x) sort(unique(as.character(x)))
