gl_parse_edges <- function(edges) {
  edges <- as.character(edges)
  if (length(edges) == 0L) return(matrix(character(0), nrow = 0L, ncol = 2L))
  parts <- strsplit(edges, ">", fixed = TRUE)
  bad <- vapply(parts, function(p) length(p) != 2L, logical(1))
  if (any(bad)) stop("malformed edge spec: ", edges[which(bad)[1L]])
  m <- t(vapply(parts, trimws, character(2)))
  rownames(m) <- NULL
  m
}

gl_topo_order <- function(nodes, edges) {
  nodes <- as.character(nodes)
  if (anyDuplicated(nodes)) stop("duplicate node labels")
  el <- gl_parse_edges(edges)
  indeg <- setNames(integer(length(nodes)), nodes)
  adj <- rep(list(character(0)), length(nodes))
  names(adj) <- nodes
  if (nrow(el) > 0L) {
    for (i in seq_len(nrow(el))) {
      from <- el[i, 1L]
      to <- el[i, 2L]
      if (!(from %in% nodes) || !(to %in% nodes))
        stop("edge references unknown node: ", from, ">", to)
      adj[[from]] <- c(adj[[from]], to)
      indeg[[to]] <- indeg[[to]] + 1L
    }
  }
  emitted <- setNames(logical(length(nodes)), nodes)
  out <- character(0)
  repeat {
    cand <- nodes[!emitted[nodes] & indeg[nodes] == 0L]
    if (length(cand) == 0L) break
    n <- cand[[1L]]
    out <- c(out, n)
    emitted[[n]] <- TRUE
    for (m in adj[[n]]) indeg[[m]] <- indeg[[m]] - 1L
  }
  if (length(out) != length(nodes)) stop("cycle detected in edge spec")
  out
}

gl_reachable <- function(edges, start) {
  el <- gl_parse_edges(edges)
  reach <- as.character(start)
  frontier <- reach
  repeat {
    if (length(frontier) == 0L || nrow(el) == 0L) break
    nxt <- unique(unlist(lapply(frontier, function(f) el[el[, 1L] == f, 2L]),
                         use.names = FALSE))
    nxt <- setdiff(nxt, reach)
    if (length(nxt) == 0L) break
    reach <- c(reach, nxt)
    frontier <- nxt
  }
  sort(unique(reach))
}
