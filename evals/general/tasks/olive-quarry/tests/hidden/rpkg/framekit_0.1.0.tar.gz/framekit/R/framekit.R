fk_scale <- function(x, lo, hi) {
  x <- as.numeric(x)
  lo <- as.numeric(lo)
  hi <- as.numeric(hi)
  if (length(x) == 0L) return(numeric(0))
  rng <- max(x) - min(x)
  if (rng == 0) return(rep((lo + hi) / 2, length(x)))
  (x - min(x)) / rng * (hi - lo) + lo
}

fk_counts <- function(x) {
  tb <- table(as.character(x))
  paste0(names(tb), ":", as.integer(tb))
}
