df_edges <- function(edges) {
  edges <- as.character(edges)
  if (length(edges) == 0L) return(matrix(character(0), nrow = 0L, ncol = 2L))
  parts <- strsplit(edges, ">", fixed = TRUE)
  bad <- vapply(parts, function(p) length(p) != 2L, logical(1))
  if (any(bad)) stop("malformed edge spec: ", edges[which(bad)[1L]])
  m <- t(vapply(parts, trimws, character(2)))
  rownames(m) <- NULL
  m
}

df_parents <- function(edges, node) {
  el <- df_edges(edges)
  if (nrow(el) == 0L) return(character(0))
  sort(unique(el[el[, 2L] == as.character(node), 1L]))
}

df_children <- function(edges, node) {
  el <- df_edges(edges)
  if (nrow(el) == 0L) return(character(0))
  sort(unique(el[el[, 1L] == as.character(node), 2L]))
}

df_all_nodes <- function(edges) {
  el <- df_edges(edges)
  if (nrow(el) == 0L) return(character(0))
  sort(unique(as.vector(el)))
}
