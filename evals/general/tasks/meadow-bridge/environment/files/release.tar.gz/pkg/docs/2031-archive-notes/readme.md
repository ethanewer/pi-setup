# notes visible
