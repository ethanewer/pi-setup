import argparse, sys
from fathom_core import depth_scale

def main(argv=None):
    p = argparse.ArgumentParser(prog="fathom-cli")
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--n", type=int, default=5)
    a = p.parse_args(argv)
    print(" ".join(str(v) for v in depth_scale(a.seed, a.n)))
    return 0

if __name__ == "__main__":
    sys.exit(main())
