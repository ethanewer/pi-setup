"""fathom_core analytics pipeline (v2.4.0, pinned)."""
__version__ = "2.4.0"
from gale_math import ramp, bounded

def depth_scale(seed, n):
    out = []
    v = seed
    for _ in range(n):
        v = ramp(v)
        out.append(bounded(v))
    return out

def tide_read(m):   # 2.x-only helper
    return "%05d" % (m % 100000)
