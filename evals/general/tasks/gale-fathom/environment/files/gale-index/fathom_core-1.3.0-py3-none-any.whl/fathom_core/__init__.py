"""fathom_core analytics, v1.3.0 (legacy ramp, no gale_math dependency)."""
__version__ = "1.3.0"

def depth_scale(seed, n):
    out = []
    for i in range(n):
        out.append((seed + i * 97) % 1000)
    return out
