"""gale_math, dependency of pinned fathom_core 2.4.0."""
__version__ = "0.6.1"

def ramp(v):
    return (v * 1103515245 + 12345) % 2147483648

def bounded(v):
    return int(v) % 1000
