def probe():
    return "probe ok"
