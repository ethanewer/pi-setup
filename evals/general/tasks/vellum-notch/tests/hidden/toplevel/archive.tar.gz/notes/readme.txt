decoy doc
