# IR-2087 triage notes

Collected from host prod-api-3.
