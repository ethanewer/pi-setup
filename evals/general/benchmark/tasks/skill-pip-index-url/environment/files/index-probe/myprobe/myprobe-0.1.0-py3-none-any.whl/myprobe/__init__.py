def friendly():
    return "hello-from-probe"
