def greet(name):
    return "hello " + name

VALUE = 41
