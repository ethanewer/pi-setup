;redcode
;name Sample-Claim
;assert 0
spl 1, 0
mov 2, 1
jmp -1, 0
end
