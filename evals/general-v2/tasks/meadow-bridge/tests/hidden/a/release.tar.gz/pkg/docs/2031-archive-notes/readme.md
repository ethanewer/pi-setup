# notes hidden_a
