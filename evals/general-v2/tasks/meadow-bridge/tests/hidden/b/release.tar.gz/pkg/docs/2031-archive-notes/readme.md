# notes hidden_b
