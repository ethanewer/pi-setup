"""lotusfields legacy 0.7.0.

This old release reads a table but does not accept the dtype_backend= keyword
and does no numeric coercion. Newer releases add the keyword and the strict
input checks; callers that rely on dtype_backend= fail loudly on this release.
"""
__version__ = "0.7.0"


def read_table(path):
    # legacy reader: accepts only the path, returns untyped rows.
    with open(path, "r", encoding="utf-8") as fh:
        lines = [ln.rstrip("\n") for ln in fh if ln.strip()]
    header = lines[0].split(",") if lines else []
    out = []
    for ln in lines[1:]:
        parts = ln.split(",")
        out.append(dict(zip(header, parts)))
    return out
