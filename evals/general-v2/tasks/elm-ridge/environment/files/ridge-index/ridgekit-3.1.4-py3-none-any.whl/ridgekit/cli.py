import argparse, sys
from .sample import score

def main(argv=None):
    p = argparse.ArgumentParser(prog="ridge-cli")
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--n", type=int, default=5)
    a = p.parse_args(argv)
    vals = score(a.seed, a.n)
    print(" ".join(str(v) for v in vals))
    return 0

if __name__ == "__main__":
    sys.exit(main())
