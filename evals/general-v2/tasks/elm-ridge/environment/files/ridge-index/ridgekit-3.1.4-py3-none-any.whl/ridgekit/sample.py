from ridgemath import accumulate

def score(seed, n):
    """Return a deterministic list of n scaled values."""
    out = []
    v = seed
    for _ in range(n):
        v = accumulate(v + 11)
        out.append(v % 1000)
    return out
