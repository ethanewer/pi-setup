"""Pinned analytics package for the ridge workspace."""
__version__ = "3.1.4"
from . import sample
